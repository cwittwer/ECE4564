Team Contributions: 
	AuthDB - MH, JASON
	Service - MH, JASON
	led - Carson
	LED_PWM - Carson
	storage - Carson
	mongodb - Carson
	
Code that was found on websites was mentioned in comments withing the files.